public class HttpRequestIndex extends HttpRequest {
    HttpRequestIndex() {
        super();
    }
    
    public Boolean readURL(String urlIn) {
        Boolean returnValue = super.readURL(urlIn);
 
        for (String line : urlContent) {
            line = line.trim();
            line = line.replace("{ \"", "");
            if (line.substring(line.length() - 1).contentEquals(",")) {
                line = line.replace("\" },", "");
            }
            else {
                line = line.replace("\" }", "");
            }
            line = line.replace("\" },", "");
            String lineTokens[] = line.split("\", \"");
           
            if (lineTokens.length > 1) {
                for (String lineToken : lineTokens) {
                    String parameterTokens[] = lineToken.split("\":\"");

                    //Searches for an https//: URL in a parameter value, and downloads/displays any URLs found
                    if (parameterTokens[1].toLowerCase().startsWith("https://")) {
                        HttpRequest entryHttpRequest = new HttpRequest();
                        if (entryHttpRequest.readURL(parameterTokens[1])) {
                            System.out.println(entryHttpRequest.toString());
                        }
                        else {
                            System.out.println("--Unable to access URL: " + parameterTokens[1]);
                        }
                    }
                }
            }
        }
       
        return returnValue;
    }
 }
 
 