import java.util.ArrayList; 

class JsonValidateIndexRequestURLs extends HttpRequest {
    // Variable Declarations.
    ArrayList<JSONValidateIndex> list;

    JsonValidateIndexRequestURLs() {
        super();
        list = new ArrayList<JSONValidateIndex>();
    }

    public Boolean readURL(String urlIn) {
        Boolean TrueOrFalse = false; 

        if (super.readURL(urlIn)) {
            for (String s : urlContent) {
                String[] subS = s.split("\"");
                if (subS.length >= 13) {
                    if (subS[11].indexOf("https://") >= 0) { 
                        list.add(new JSONValidateIndex(subS[11])); 
                        TrueOrFalse = true; 
                    }
                }
            }
        }

        if (TrueOrFalse) { 
            for (HttpRequest s : list) {
                s.readURL(s.requestURL);
            } 
        }
        return TrueOrFalse;
    }

    public String toString() { //Implements toString
        String returnStatement = "";
        for (HttpRequest d : list) {
            returnStatement = returnStatement + "\n" + d;
        }
        return returnStatement;
    }
    
    public void CharacterInformation() {
        for (JSONValidateIndex JsonVI : list) {
            JsonVI.TrueOrFalse();
        }
        System.out.println(); 
    }

    public void ValidateCharacterInformation() {
        System.out.println("Validating firstName, lastName, & email: ");
        for (JSONValidateIndex JsonVI : list) {
            JsonVI.Validate();
        }
        System.out.println();
    }
}
