import java.util.ArrayList;

class Help {
    public static void printHelp() {
        //Builds arraylist for help messages 
        ArrayList<String> help = new ArrayList<String>(); 

        System.out.println("\nWelcome to Swiss Army Knife 2.0! Please use the following information to help you out in using this program."); 
        System.out.println("\nP.S: New implementions are listed first! "); 
        System.out.println(); 
        System.out.println("Possible arguements: ");
        System.out.println("-Help: Prints help and usage guide for this application.");
        System.out.println("-HttpRequest [URL]: Downloads [URL] and displays downloaded website on console.");
        System.out.println("-HttpRequestIndex [URL]: Expects [URL] to be a simple JSON file, containing URLs, and attempts to download and display the contents of those JSON files");
        System.out.println("\nSleep non-threaded and threaded implementation examples: ");
        System.out.println("java sak -Sleep"); 
        System.out.println("java sak -SleepFast");
        System.out.println("java sak -SleepFastImplementsRunnable");
        System.out.println(); 
        System.out.println("Reads JSON index and validates personal information using threaded implementation. Example: "); 
        System.out.println("java sak -JSONValidateIndexThreaded"); 
        System.out.println("\nReads JSON index and validates personal information using non-threaded implementation. Example: ");
        System.out.println("java sak -JSONValidateIndex"); 
        System.out.println("\nHttpRequest [URL] examples:");
        System.out.println("java sak -HttpRequest https://www.cnn.com");
        System.out.println("java sak -HttpRequest https://thunderbird-data-jm1.azurewebsites.net/spideysense.json");
        System.out.println("\nHttpRequestIndex [URL] example:");
        System.out.println("java sak -HttpRequestIndex https://thunderbird-index.azurewebsites.net/w0a6zk195d.json");
    }
}