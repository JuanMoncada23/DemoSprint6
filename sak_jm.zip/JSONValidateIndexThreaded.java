import java.util.ArrayList; 

class JSONValidateIndexThreaded extends HttpRequest implements Runnable {
    private int validateNumber; 

    JSONValidateIndexThreaded(int validateNumberIn) {
        validateNumber = validateNumberIn; 
    }

    public void run() {
        String indexURL = "https://thunderbird-index.azurewebsites.net/w0a6zk195d.json"; 

        JsonValidateIndexRequestURLs jsonRequest = new JsonValidateIndexRequestURLs();
        if(jsonRequest.readURL(indexURL)) {
            jsonRequest.CharacterInformation(); 
            jsonRequest.ValidateCharacterInformation(); 
        }
    }
}