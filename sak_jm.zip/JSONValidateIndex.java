class JSONValidateIndex extends HttpRequest implements Runnable {
    private String firstName;
    private String lastName; 
    private String email; 

    public String getFirstName() {
        return firstName; 
    }
    public String getLastName() {
        return lastName; 
    }
    public String email() {
        return email; 
    }

    
    JSONValidateIndex(String urlIn) {
        super(urlIn); 

        firstName = ""; 
        lastName = "";
        email = ""; 
    }

    public Boolean TrueOrFalse() {
        Boolean returnValue = false; 
        System.out.println(requestURL); 
        if(super.readURL()) {
            Parse(); 
            returnValue = true; 
        }
        return returnValue; 
    }

    public void Parse() {
        for(String s : urlContent) {
            String[] subString = s.split("\""); 
            String regex =  "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";

            if(subString.length > 2 && subString.length < 16) {
                if(subString[1].equals("firstName")) {
                    firstName = subString[3]; 
                }
                if(subString[1].equals("lastName")) {
                    lastName = subString[3];
                }
                if(subString[1].equals("email")) {
                    email = regex; 
                }
                

            }
        }
    }

    public void Validate() {
        if(firstName.length() == 0) {
            System.out.println("Validating: " + requestURL);
            System.out.println(" Failed: First name was not found"); 
        } else if(lastName.length() == 0) {
            System.out.println("Validating: " + requestURL);
            System.out.println(" Failed: Last Name was not found");
        } else if(email.length() == 0) {
            System.out.println("Validating: " + requestURL);
            System.out.println(" Failed: Email was not found"); 
        }
        else {
            System.out.println("Validating: " + requestURL + "... Passed!");
        }
    }

    public void run() {
        TrueOrFalse(); 
    }
}